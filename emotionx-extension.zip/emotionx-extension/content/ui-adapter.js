// Applies emotion-driven UI hints non-intrusively.

const EMOTION_ACTIONS = {
  confused: 'Showing comparison helpers',
  frustrated: 'Offering support-friendly messaging',
  impulsive: 'Highlighting urgency cues',
  engaged: 'Highlighting bundles and recommendations',
  indecisive: 'Highlighting best-seller badges',
  calm: 'Showing premium options',
  happy: 'Reinforcing positive feedback',
  neutral: 'Maintaining baseline layout',
  focused: 'Reducing distractions',
  disappointed: 'Softening upsell pressure'
};

class UiAdapter {
  applyEmotion(result) {
    const emotion = result?.emotion;
    if (!emotion) return;

    const actionDescription = EMOTION_ACTIONS[emotion] || '';

    document.documentElement.dataset.emotionxEmotion = emotion;
    document.documentElement.dataset.emotionxAction = actionDescription;

    // Example adaptation: tweak banners/buttons by attribute selectors.
    // Real sites can target [data-emotionx-emotion="confused"] in custom CSS.
  }
}

