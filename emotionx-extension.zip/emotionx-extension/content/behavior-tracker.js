// Tracks scroll, mouse, clicks, idle time and cart-like interactions.

class BehaviorTracker {
  constructor() {
    this.reset();
    this.idleTimeout = null;
    this.idleThresholdMs = 5000;
    this.flushIntervalMs = 4000;
    this.flushTimer = null;
  }

  reset() {
    this.data = {
      scrollDistances: [],
      scrollTimestamps: [],
      mouseMovements: [],
      mouseTimestamps: [],
      clicks: 0,
      hovers: 0,
      hoverDurations: [],
      cartAdds: 0,
      cartRemovals: 0,
      lastActiveAt: performance.now(),
      tabSwitches: 0
    };
  }

  start(onSnapshot) {
    this.onSnapshot = onSnapshot;

    window.addEventListener('scroll', this.onScroll, { passive: true });
    window.addEventListener('mousemove', this.onMouseMove, { passive: true });
    window.addEventListener('click', this.onClick, true);
    window.addEventListener('visibilitychange', this.onVisibilityChange);

    this.observeHovers();
    this.observeCartButtons();

    this.flushTimer = window.setInterval(() => {
      this.flush();
    }, this.flushIntervalMs);
  }

  stop() {
    window.removeEventListener('scroll', this.onScroll);
    window.removeEventListener('mousemove', this.onMouseMove);
    window.removeEventListener('click', this.onClick, true);
    window.removeEventListener('visibilitychange', this.onVisibilityChange);

    if (this.flushTimer) window.clearInterval(this.flushTimer);
    if (this.idleTimeout) window.clearTimeout(this.idleTimeout);
  }

  touchActivity() {
    this.data.lastActiveAt = performance.now();
    if (this.idleTimeout) window.clearTimeout(this.idleTimeout);
    this.idleTimeout = window.setTimeout(() => {
      this.flush();
    }, this.idleThresholdMs);
  }

  onScroll = () => {
    const now = performance.now();
    const distance = Math.abs(window.scrollY - (this.lastScrollY || 0));
    this.lastScrollY = window.scrollY;

    this.data.scrollDistances.push(distance);
    this.data.scrollTimestamps.push(now);
    this.touchActivity();
  };

  onMouseMove = (e) => {
    const now = performance.now();
    if (this.lastMousePos) {
      const dx = e.clientX - this.lastMousePos.x;
      const dy = e.clientY - this.lastMousePos.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      this.data.mouseMovements.push(dist);
      this.data.mouseTimestamps.push(now);
    }
    this.lastMousePos = { x: e.clientX, y: e.clientY };
    this.touchActivity();
  };

  onClick = () => {
    this.data.clicks += 1;
    this.touchActivity();
  };

  onVisibilityChange = () => {
    if (document.visibilityState === 'hidden') {
      this.data.tabSwitches += 1;
      this.flush();
    }
  };

  observeHovers() {
    const hovered = new WeakMap();

    document.addEventListener(
      'mouseover',
      (e) => {
        const el = e.target;
        if (!el || hovered.has(el)) return;
        hovered.set(el, performance.now());
      },
      true
    );

    document.addEventListener(
      'mouseout',
      (e) => {
        const el = e.target;
        if (!el || !hovered.has(el)) return;
        const start = hovered.get(el);
        const dur = performance.now() - start;
        this.data.hovers += 1;
        this.data.hoverDurations.push(dur);
        hovered.delete(el);
      },
      true
    );
  }

  observeCartButtons() {
    document.addEventListener(
      'click',
      (e) => {
        const target = e.target;
        if (!target) return;
        const text = String(target.textContent || '').toLowerCase();
        if (text.includes('add to cart') || text.includes('add to bag')) {
          this.data.cartAdds += 1;
        }
        if (text.includes('remove') || text.includes('delete')) {
          this.data.cartRemovals += 1;
        }
      },
      true
    );
  }

  flush() {
    if (!this.onSnapshot) return;
    const snapshot = { ...this.data };
    this.reset();
    this.onSnapshot(snapshot);
  }
}

