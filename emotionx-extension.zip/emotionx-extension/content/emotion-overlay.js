// Small floating overlay that shows current emotion + confidence.

class EmotionOverlay {
  constructor() {
    this.root = null;
  }

  mount() {
    if (this.root) return;
    const el = document.createElement('div');
    el.id = 'emotionx-overlay';
    el.style.position = 'fixed';
    el.style.bottom = '16px';
    el.style.right = '16px';
    el.style.zIndex = '2147483647';
    el.style.background = 'rgba(17,24,39,0.92)';
    el.style.color = '#f9fafb';
    el.style.padding = '8px 12px';
    el.style.borderRadius = '999px';
    el.style.fontFamily = 'system-ui, -apple-system, BlinkMacSystemFont, sans-serif';
    el.style.fontSize = '12px';
    el.style.display = 'flex';
    el.style.alignItems = 'center';
    el.style.gap = '6px';
    el.style.boxShadow = '0 10px 25px rgba(0,0,0,0.35)';
    el.style.pointerEvents = 'none';

    const dot = document.createElement('span');
    dot.style.width = '8px';
    dot.style.height = '8px';
    dot.style.borderRadius = '999px';
    dot.style.background = '#22c55e';
    dot.id = 'emotionx-overlay-dot';

    const text = document.createElement('span');
    text.id = 'emotionx-overlay-text';
    text.textContent = 'EmotionX idle';
    el.appendChild(dot);
    el.appendChild(text);

    document.documentElement.appendChild(el);
    this.root = el;
  }

  update(result) {
    if (!this.root) return;
    const text = this.root.querySelector('#emotionx-overlay-text');
    const dot = this.root.querySelector('#emotionx-overlay-dot');
    if (!text || !dot) return;

    if (!result) {
      text.textContent = 'EmotionX idle';
      dot.style.background = '#6b7280';
      return;
    }

    const { emotion, confidence, source } = result;
    text.textContent = `${emotion || 'unknown'} • ${(confidence * 100).toFixed(0)}% • ${source || 'behavior'}`;

    if (confidence >= 0.8) dot.style.background = '#22c55e';
    else if (confidence >= 0.6) dot.style.background = '#eab308';
    else dot.style.background = '#f97316';
  }
}

