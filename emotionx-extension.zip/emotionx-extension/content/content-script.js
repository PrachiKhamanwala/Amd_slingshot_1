// Entry point injected into shopping sites.
// Wires behavior tracker, webcam controller (via messages), and UI adaptation.

// Helper classes/functions are loaded as globals via manifest content_scripts order.
const emotionEngine = new EmotionEngine();
const behaviorTracker = new BehaviorTracker();
const domObserver = new DomObserver();
const uiAdapter = new UiAdapter();
const overlay = new EmotionOverlay();

let latestSettings = null;

function init() {
  chrome.runtime.sendMessage({ type: 'GET_SETTINGS' }, settings => {
    latestSettings = settings;

    domObserver.start();
    overlay.mount();

    if (settings.behaviorModeEnabled && settings.consentAcknowledged) {
      behaviorTracker.start(onBehaviorFeatures);
    }
  });
}

function onBehaviorFeatures(behaviorSnapshot) {
  if (!latestSettings?.behaviorModeEnabled || !latestSettings?.consentAcknowledged) return;

  const features = extractBehaviorFeatures(behaviorSnapshot);
  const result = emotionEngine.inferFromBehavior(features);

  if (!result) return;

  chrome.runtime.sendMessage(
    {
      type: 'EMOTION_UPDATE',
      payload: {
        ...result,
        source: 'behavior'
      }
    },
    () => {}
  );

  uiAdapter.applyEmotion(result);
  overlay.update(result);
}

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'EMOTION_STATE') {
    uiAdapter.applyEmotion(message.payload);
    overlay.update(message.payload);
  }
});

init();

