// High-level webcam emotion pipeline: camera + motion analyzer + emotion engine.

import { CameraController } from './camera-controller.js';
import { MotionAnalyzer } from './motion-analyzer.js';
import { EmotionEngine } from '../ai/emotion-engine.js';

export class ExpressionClassifier {
  constructor() {
    this.camera = new CameraController();
    this.motionAnalyzer = new MotionAnalyzer();
    this.engine = new EmotionEngine();
    this.canvas = document.createElement('canvas');
    this.running = false;
    this.onEmotion = null;
  }

  async start(onEmotion) {
    if (this.running) return;
    this.onEmotion = onEmotion;
    await this.camera.start();
    this.running = true;
    this.loop();
  }

  stop() {
    this.running = false;
    this.camera.stop();
  }

  loop = () => {
    if (!this.running) return;
    const frame = this.camera.getFrame(this.canvas);
    const signals = this.motionAnalyzer.analyze(frame);
    if (signals) {
      const result = this.engine.inferFromFacialSignals(signals);
      if (this.onEmotion && result) {
        this.onEmotion(result);
      }
    }
    setTimeout(this.loop, 400);
  };
}

