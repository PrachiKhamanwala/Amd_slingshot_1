// High-level emotion engine that delegates to rule engine.

// RuleEngine is defined globally from rule-engine.js
class EmotionEngine {
  constructor() {
    this.ruleEngine = new RuleEngine();
  }

  inferFromBehavior(features) {
    return this.ruleEngine.inferFromBehavior(features);
  }

  inferFromFacialSignals(signals) {
    return this.ruleEngine.inferFromFacialSignals(signals);
  }
}

