// Simple rule-based emotion inference for MVP.

class RuleEngine {
  inferFromBehavior(features) {
    const {
      avgScrollSpeed,
      mouseAcceleration,
      hoverTime,
      clickRate,
      idleTime,
      cartFluctuation,
      tabSwitches
    } = features;

    const candidates = [];

    if (hoverTime > 2500 && cartFluctuation === 0 && clickRate < 0.05) {
      candidates.push({ emotion: 'confused', confidence: 0.8 });
    }

    if (tabSwitches > 1 || idleTime > 15000) {
      candidates.push({ emotion: 'frustrated', confidence: 0.75 });
    }

    if (cartFluctuation >= 2 && clickRate > 0.1) {
      candidates.push({ emotion: 'indecisive', confidence: 0.78 });
    }

    if (cartFluctuation >= 3 && avgScrollSpeed > 150) {
      candidates.push({ emotion: 'impulsive', confidence: 0.82 });
    }

    if (avgScrollSpeed > 80 && hoverTime > 1500 && clickRate > 0.08) {
      candidates.push({ emotion: 'engaged', confidence: 0.76 });
    }

    if (avgScrollSpeed < 40 && mouseAcceleration < 30 && clickRate < 0.05 && idleTime < 8000) {
      candidates.push({ emotion: 'calm', confidence: 0.7 });
    }

    if (!candidates.length) {
      return { emotion: 'neutral', confidence: 0.55 };
    }

    candidates.sort((a, b) => b.confidence - a.confidence);
    return candidates[0];
  }

  inferFromFacialSignals(signals) {
    const { smile, eyebrowRaise, eyeOpenness, headTilt, motionIntensity } = signals;
    const candidates = [];

    if (smile > 0.6 && eyeOpenness > 0.4) {
      candidates.push({ emotion: 'happy', confidence: 0.82 });
    }

    if (eyebrowRaise > 0.6 && eyeOpenness > 0.5) {
      candidates.push({ emotion: 'surprised', confidence: 0.8 });
    }

    if (eyeOpenness < 0.3 && motionIntensity > 0.6) {
      candidates.push({ emotion: 'frustrated', confidence: 0.78 });
    }

    if (headTilt > 0.4 && eyebrowRaise > 0.4) {
      candidates.push({ emotion: 'confused', confidence: 0.75 });
    }

    if (motionIntensity < 0.25 && eyeOpenness > 0.4) {
      candidates.push({ emotion: 'focused', confidence: 0.7 });
    }

    if (!candidates.length) {
      return { emotion: 'neutral', confidence: 0.55 };
    }

    candidates.sort((a, b) => b.confidence - a.confidence);
    return candidates[0];
  }
}

